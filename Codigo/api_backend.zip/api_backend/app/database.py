"""Configuração da base de dados (SQLite) partilhada por toda a API.

SQLite é suficiente para as necessidades de desenvolvimento e demonstração
deste projeto (ver Aplicacao_Mobile.docx), podendo ser substituído por um
SGBD mais robusto (ex.: PostgreSQL) caso a aplicação venha a ser escalada -
bastaria então alterar SQLALCHEMY_DATABASE_URL, o resto do código (modelos,
queries) não depende do motor de base de dados escolhido.
"""
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DB_PATH = Path(__file__).resolve().parent.parent / "app.db"
SQLALCHEMY_DATABASE_URL = f"sqlite:///{DB_PATH}"

# check_same_thread=False é necessário porque o Uvicorn pode atender
# pedidos em threads diferentes; cada pedido continua a usar a sua própria
# sessão (ver get_db), pelo que isto é seguro.
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """Dependency do FastAPI: abre uma sessão de base de dados por pedido e
    garante que é sempre fechada no final, mesmo em caso de erro."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
