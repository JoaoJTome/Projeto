"""Instância única e partilhada do motor de recomendação.

O dataset base (CSV + codificação one-hot) é razoavelmente caro de carregar,
por isso é feito uma única vez por processo da API e reutilizado em todos os
pedidos, em vez de recarregado a cada chamada.
"""
from functools import lru_cache

from .recommendation_engine import RecommendationEngine


@lru_cache
def get_engine() -> RecommendationEngine:
    return RecommendationEngine()
