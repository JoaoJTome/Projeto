"""Testes de ponta a ponta da API, usando o dataset sintético definido em
conftest.py. Correr com `pytest` a partir da pasta api_backend/.
"""


def test_register_login_logout_flow(client):
    resp = client.post(
        "/auth/register",
        json={
            "email": "ana@example.com",
            "password": "palavra-passe-1",
            "password_confirmation": "palavra-passe-1",
        },
    )
    assert resp.status_code == 201
    token = resp.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}

    # o token emitido no registo dá acesso imediato a rotas protegidas
    resp = client.get("/lists", headers=headers)
    assert resp.status_code == 200
    assert resp.json() == []

    # logout invalida o token do lado do servidor
    resp = client.post("/auth/logout", headers=headers)
    assert resp.status_code == 204
    resp = client.get("/lists", headers=headers)
    assert resp.status_code == 401

    # login emite um novo token válido
    resp = client.post(
        "/auth/login", json={"email": "ana@example.com", "password": "palavra-passe-1"}
    )
    assert resp.status_code == 200
    assert resp.json()["token"]


def test_login_with_wrong_password_is_rejected(client):
    client.post(
        "/auth/register",
        json={"email": "x@example.com", "password": "12345678", "password_confirmation": "12345678"},
    )
    resp = client.post("/auth/login", json={"email": "x@example.com", "password": "errada123"})
    assert resp.status_code == 401


def test_register_rejects_mismatched_passwords(client):
    resp = client.post(
        "/auth/register",
        json={"email": "b@example.com", "password": "12345678", "password_confirmation": "diferente"},
    )
    assert resp.status_code == 422


def test_register_rejects_duplicate_email(client):
    payload = {
        "email": "dup@example.com",
        "password": "12345678",
        "password_confirmation": "12345678",
    }
    assert client.post("/auth/register", json=payload).status_code == 201
    assert client.post("/auth/register", json=payload).status_code == 409


def test_protected_routes_require_token(client):
    assert client.get("/lists").status_code in (401, 422)
    resp = client.get("/lists", headers={"Authorization": "Bearer token-invalido"})
    assert resp.status_code == 401


def test_items_endpoint_lists_and_searches_dataset_items(client):
    resp = client.get("/items")
    assert resp.status_code == 200
    items = resp.json()
    assert set(items) == {"milk", "bread", "eggs", "butter"}

    resp = client.get("/items", params={"search": "mil"})
    assert resp.json() == ["milk"]


def _register(client, email="c@example.com"):
    resp = client.post(
        "/auth/register",
        json={"email": email, "password": "12345678", "password_confirmation": "12345678"},
    )
    token = resp.json()["token"]
    return {"Authorization": f"Bearer {token}"}


def test_save_list_and_history(client):
    headers = _register(client)

    resp = client.post("/lists", json={"items": ["Milk", "Bread"]}, headers=headers)
    assert resp.status_code == 201
    body = resp.json()
    # os itens guardados ficam em minúsculas, tal como o dataset
    assert {i["item_name"] for i in body["items"]} == {"milk", "bread"}

    resp = client.get("/lists", headers=headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 1


def test_recommendations_exclude_current_items_and_respect_limit(client):
    headers = _register(client, email="d@example.com")
    client.post("/lists", json={"items": ["milk", "bread"]}, headers=headers)

    resp = client.put(
        "/admin/settings",
        json={"min_support": 0.1, "min_confidence": 0.3, "user_weight": 3},
    )
    assert resp.status_code == 200

    resp = client.post(
        "/recommendations", json={"current_items": ["milk"]}, headers=headers
    )
    assert resp.status_code == 200
    recommended = resp.json()["recommended_items"]
    assert "milk" not in recommended
    assert len(recommended) <= 5


def test_admin_settings_roundtrip(client):
    resp = client.get("/admin/settings")
    assert resp.status_code == 200
    assert resp.json() == {"min_support": 0.01, "min_confidence": 0.2, "user_weight": 3}

    resp = client.put(
        "/admin/settings",
        json={"min_support": 0.2, "min_confidence": 0.5, "user_weight": 10},
    )
    assert resp.status_code == 200

    resp = client.get("/admin/settings")
    assert resp.json() == {"min_support": 0.2, "min_confidence": 0.5, "user_weight": 10}


def test_admin_stats_top_items_and_rules(client):
    resp = client.get("/admin/stats/top-items")
    assert resp.status_code == 200
    top = resp.json()
    assert top[0]["item"] in {"milk", "bread"}  # os mais frequentes no dataset de teste

    client.put(
        "/admin/settings",
        json={"min_support": 0.1, "min_confidence": 0.3, "user_weight": 3},
    )
    resp = client.get("/admin/stats/rules")
    assert resp.status_code == 200
    rules = resp.json()
    assert len(rules) > 0
    assert set(rules[0].keys()) == {"antecedents", "consequents", "support", "confidence", "lift"}
