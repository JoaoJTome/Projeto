import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'login_screen.dart';
import 'new_list_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<SavedList>> _listsFuture;

  @override
  void initState() {
    super.initState();
    _listsFuture = ApiService.instance.getLists();
  }

  Future<void> _refresh() async {
    setState(() {
      _listsFuture = ApiService.instance.getLists();
    });
  }

  Future<void> _logout() async {
    await ApiService.instance.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('As minhas listas'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Terminar sessão',
            onPressed: _logout,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add_shopping_cart),
        label: const Text('Nova lista'),
        onPressed: () async {
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const NewListScreen()),
          );
          _refresh();
        },
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<List<SavedList>>(
          future: _listsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return _errorView(snapshot.error.toString());
            }
            final lists = snapshot.data ?? [];
            if (lists.isEmpty) {
              return ListView(
                children: const [
                  SizedBox(height: 120),
                  Icon(Icons.shopping_basket_outlined, size: 48, color: Colors.grey),
                  SizedBox(height: 12),
                  Center(child: Text('Ainda não tem listas guardadas.')),
                ],
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: lists.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final list = lists[index];
                return ListTile(
                  leading: const Icon(Icons.receipt_long),
                  title: Text('${list.items.length} itens'),
                  subtitle: Text(_formatDate(list.createdAt)),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget _errorView(String message) {
    return ListView(
      children: [
        const SizedBox(height: 120),
        const Icon(Icons.error_outline, size: 48, color: Colors.grey),
        const SizedBox(height: 12),
        Center(child: Text('Não foi possível carregar o histórico.\n$message', textAlign: TextAlign.center)),
        const SizedBox(height: 12),
        Center(child: TextButton(onPressed: _refresh, child: const Text('Tentar novamente'))),
      ],
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }
}
