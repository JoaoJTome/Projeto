import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Erro simples para mostrar mensagens legíveis na UI.
class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// Um item de uma lista de compras, tal como devolvido pela API.
/// No dataset do projeto os itens são identificados pelo nome
/// (ex.: "whole milk"), por isso mantemos apenas esse campo por agora.
/// Se a API devolver mais campos (categoria, id, etc.), acrescentar aqui.
class ShoppingItem {
  final String name;
  ShoppingItem(this.name);

  factory ShoppingItem.fromJson(dynamic json) {
    if (json is String) return ShoppingItem(json);
    return ShoppingItem(json['name'] ?? json['item'] ?? json.toString());
  }
}

/// Uma lista de compras guardada (histórico do utilizador).
class SavedList {
  final String id;
  final DateTime createdAt;
  final List<String> items;

  SavedList({required this.id, required this.createdAt, required this.items});

  factory SavedList.fromJson(Map<String, dynamic> json) {
    return SavedList(
      // TODO: confirmar o nome exato do campo de id/data no
      // api_backend/app/models.py (ShoppingList) e ajustar aqui.
      id: (json['id'] ?? '').toString(),
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      items: List<String>.from(
        (json['items'] ?? []).map((i) => i is String ? i : (i['name'] ?? i.toString())),
      ),
    );
  }
}

class ApiService {
  ApiService._internal();
  static final ApiService instance = ApiService._internal();

  // TODO: em desenvolvimento no emulador Android usar 10.0.2.2 em vez de
  // localhost, para chegar à máquina anfitriã onde a API está a correr.
  static const String baseUrl = 'http://10.0.2.2:8000';

  String? _token;

  Future<void> _loadToken() async {
    if (_token != null) return;
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('auth_token');
  }

  Future<void> _saveToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  Future<void> _clearToken() async {
    _token = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }

  Future<bool> hasSession() async {
    await _loadToken();
    return _token != null;
  }

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  dynamic _decode(http.Response resp) {
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      if (resp.body.isEmpty) return null;
      return jsonDecode(resp.body);
    }
    String msg = 'Erro (${resp.statusCode})';
    try {
      final body = jsonDecode(resp.body);
      msg = body['detail']?.toString() ?? msg;
    } catch (_) {}
    throw ApiException(msg);
  }

  // ---- Autenticação --------------------------------------------------

  Future<void> register(String email, String password) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: _headers,
      body: jsonEncode({'email': email, 'password': password}),
    );
    final data = _decode(resp);
    // TODO: confirmar se /auth/register já devolve um token (login
    // automático) ou se é preciso chamar login() a seguir.
    if (data is Map && data['token'] != null) {
      await _saveToken(data['token']);
    } else {
      await login(email, password);
    }
  }

  Future<void> login(String email, String password) async {
    final resp = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: _headers,
      body: jsonEncode({'email': email, 'password': password}),
    );
    final data = _decode(resp);
    final token = data is Map ? data['token'] ?? data['access_token'] : null;
    if (token == null) {
      throw ApiException('Resposta de login inesperada.');
    }
    await _saveToken(token);
  }

  Future<void> logout() async {
    await _loadToken();
    try {
      await http.post(Uri.parse('$baseUrl/auth/logout'), headers: _headers);
    } catch (_) {
      // Mesmo que a chamada de rede falhe, terminamos a sessão localmente.
    }
    await _clearToken();
  }

  // ---- Itens e listas --------------------------------------------------

  Future<List<String>> searchItems(String query) async {
    await _loadToken();
    final resp = await http.get(
      Uri.parse('$baseUrl/items').replace(queryParameters: {'q': query}),
      headers: _headers,
    );
    final data = _decode(resp) as List<dynamic>? ?? [];
    return data.map((i) => i is String ? i : (i['name']?.toString() ?? i.toString())).toList();
  }

  Future<List<SavedList>> getLists() async {
    await _loadToken();
    final resp = await http.get(Uri.parse('$baseUrl/lists'), headers: _headers);
    final data = _decode(resp) as List<dynamic>? ?? [];
    return data.map((e) => SavedList.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> saveList(List<String> items) async {
    await _loadToken();
    final resp = await http.post(
      Uri.parse('$baseUrl/lists'),
      headers: _headers,
      body: jsonEncode({'items': items}),
    );
    _decode(resp);
  }

  Future<List<String>> getRecommendations(List<String> currentItems) async {
    await _loadToken();
    final resp = await http.post(
      Uri.parse('$baseUrl/recommendations'),
      headers: _headers,
      body: jsonEncode({'items': currentItems}),
    );
    final data = _decode(resp) as List<dynamic>? ?? [];
    return data.map((i) => i is String ? i : (i['name']?.toString() ?? i.toString())).toList();
  }
}
