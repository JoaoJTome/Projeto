# mercado_app — App Mobile (Flutter)

Esqueleto simples da aplicação mobile descrita em `Aplicacao_Mobile.docx`,
a consumir a API FastAPI já implementada em `api_backend/`.

## Ecrãs incluídos

- **Login** (`login_screen.dart`) — Figura 1
- **Criar Conta** (`register_screen.dart`) — Figura 2
- **Início / histórico de listas** (`home_screen.dart`) — Figura 3
- **Nova Lista de Compras** — pesquisa, lista atual e recomendações
  (`new_list_screen.dart`) — Figura 4

Cobre os casos de uso: Autenticar-se, Criar Conta, Consultar Histórico de
Listas, Criar Nova Lista de Compras, Adicionar Item à Lista, Consultar
Itens Recomendados, Adicionar Item Recomendado à Lista, Guardar Lista de
Compras e Terminar Sessão.

Ficou de fora, por simplicidade: recuperação de password (mencionada no
mockup do Login mas sem caso de uso próprio no documento).

## Como arrancar

Este projeto contém apenas o código-fonte (`lib/` + `pubspec.yaml`), sem
as pastas `android/` e `ios/` geradas pelo Flutter — precisam de as criar
localmente:

```bash
# 1. Criar as pastas de plataforma dentro desta mesma pasta
flutter create --project-name mercado_app .

# 2. Instalar dependências
flutter pub get

# 3. Correr a API backend (noutro terminal, a partir de api_backend/)
uvicorn app.main:app --reload

# 4. Correr a app (emulador Android ou dispositivo)
flutter run
```

## Importante — confirmar com o código real da API

Não tive acesso ao código-fonte de `api_backend/`, só à descrição em
`Arquitetura_Geral_Sistema.md`. Fiz por isso assunções razoáveis sobre o
formato dos pedidos/respostas, marcadas com `// TODO` em
`lib/services/api_service.dart`. Antes de testar, confirmem sobretudo:

1. **Nomes dos campos de login/registo** — assumi
   `{"email": ..., "password": ...}` e que a resposta tem um campo
   `token` ou `access_token`. Ajustar em `login()` e `register()`.
2. **Se `/auth/register` já devolve sessão** — se não devolver, o código
   já trata disso chamando `login()` a seguir; se devolver, simplificar.
3. **Formato de `/items`, `/lists` e `/recommendations`** — assumi que
   itens são strings simples (nomes de produtos) e que `/lists` devolve
   uma lista de objetos com `id`, `created_at` e `items`. Ajustar
   `ShoppingItem`/`SavedList` em `api_service.dart` conforme os schemas
   Pydantic reais em `api_backend/app/models.py`.
4. **URL da API** — `baseUrl` está definido como `http://10.0.2.2:8000`
   (endereço da máquina anfitriã visto do emulador Android). Num
   dispositivo físico, substituir pelo IP da máquina na rede local; em
   iOS Simulator, `http://localhost:8000` funciona diretamente.

## Estrutura

```
lib/
  main.dart                    # arranque + decide Login vs Início
  services/api_service.dart    # toda a comunicação HTTP + token
  screens/
    login_screen.dart
    register_screen.dart
    home_screen.dart
    new_list_screen.dart
```

Gestão de estado propositadamente simples (`setState`), sem Provider/
Riverpod — para um projeto deste âmbito não é necessário mais.
